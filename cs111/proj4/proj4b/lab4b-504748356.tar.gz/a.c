#include <stdio.h>
#include <mraa.h>
#include <sys/time.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <limits.h>

char timeBuffer[9];
char scale = 'C';
mraa_aio_context tempSensor;
mraa_gpio_context button;
int logFile, logging;
int inteval = 1;

void handle_period_change(char *buf){
//	code adapted from http://man7.org/linux/man-pages/man3/strtol.3.html
	long val;
	char *str = buf + strlen("PERIOD=");
	char *end;
	errno = 0;
	val = strtol(str, &end, 10);
	//since this won't be checked (from a Piazza post) we're just gonna terminate if PERIOD=x is bad
	if( (errno = ERANGE && (val == LONG_MAX || val == LONG_MIN)) || (errno != 0 && val == 0)) {
		err_exit("strtol: invalid number", errno);
	}
	else if(end == str) {
		err_exit("strtol: no numbers found", errno);
	}
	else if(val < 0) {
		err_exit("negative value", errno);
	}
	else {
		interval = val;
		if(logging) {
			fprintf(logger, "%s%lu\n", "PERIOD=", val);
		//	fflush(logger);
		}
	}
}

void getTime(char * formattedTime){
  time_t clock;
  struct tm* timeInfo;
  time(&clock);
  timeInfo = localtime(&clock);
  // store the time string in the buffer
  strftime(formattedTime, 9, "%H:%M:%S", timeInfo);
}

void * inputFunc(void *arg){
	char buf[512];
	while(1) {
		//f(!first_temp_read) continue; //just spin for the first temperature read because it will happen quickly
		int x = read(STDIN_FILENO, buf, 512);
		//if(x < 0) err_exit("read failed \n", errno);
		if (x > 0){
			int i; int start = 0; //for multi command processing
			for(i = 0; i < x; i++){
				if(buf[i] == '\n'){ //from piazza: commands are logged (if logging is on) but never output to stdout.
					buf[i] = 0 ; //set null byte to where \n is
					if(strcmp(buf + start, "OFF") == 0){
            char curtime[10];
          	getTime(curtime);
          	if(logging){
          		fprintf(logger, "%s\n", "OFF");
          		fprintf(logger, "%s %s\n", curtime, "SHUTDOWN");
          	}
            exit(0);
          }
					else if(strcmp(buf + start, "STOP") == 0){
            report = 0;
            if(logging){
              fprintf(logger, "STOP\n");
              //fflush(logger);
            }
          }
					else if(strcmp(buf + start, "START") == 0){
            report = 1;
            if(logging){
              fprintf(logger, "START\n");
              //fflush(logger);
            }
          }
					else if (strcmp(buf + start, "SCALE=C") == 0){
            scale = "C";
            fprintf(logger, "SCALE=%s", scale);
          }
					else if(strcmp(buf + start, "SCALE=F") == 0){
            scale = "F";
            fprintf(logger, "SCALE=%s", scale);
          }
					else if(strncmp(buf + start, "PERIOD=", strlen("PERIOD=")) == 0)handle_period_change(buf + start);
					else {//command is invalid. by @448: Log the error message in the file and exit (without any output to stdout)
						if(logging){
							char *k = buf + start;
							fprintf(logger, "%s %s\n", "Invalid command:", k);
						}
						exit(1);
					}
					start = i + 1; //begin command processing (if we have more) after the \n
				}
			}
		}
	}
	return NULL;
}
void * btnFunc(){
//	if(debug) printf("in io func thread \n");
	while(1){
		if(mraa_gpio_read(button)){
			char curtime[10];
			getTime(curtime);
			if(logging)
        fprintf(logger, "%s %s\n", curtime, "SHUTDOWN");
			//fprintf(stdout, "%s %s \n", time, "SHUTDOWN"); from piazza 510: don't have to print shutdown to stdout
			//if(log_flag) fflush(logger);
			exit(0);
		}
	}
	return NULL;
}

void * tempFunc(){
    while (1){
      int a = mraa_aio_read(tempSensor);
      float R = 1023.0/a-1.0;
      R = R0*R;

      double R = 1023.0/((double)a) - 1.0;
  		R = 100000.0*R;
  		double celsius  = 1.0/(log(R/100000.0)/B + 1/298.15) - 273.15;
  		// convert from Celsius to Fahrenheit
  		double fahrenheit = celsius * 9/5 + 32;

      char curtime[10];
      if(report){
        if (logging) fprintf(logFile, "%s %.1f\n", curtime, scale=='F' ? fahrenheit : celsius);
        fprintf(stdout, "%s %.1f\n", curtime, scale=='F' ? fahrenheit : celsius);
      }

      // make sure output is printed to the log file and shell
  		fflush(logFile);
  		fflush(stdout);

      sleep(interval);
    }
    return NULL;
}

int main(int argc, char** argv){
  tempSensor = mraa_aio_init(1);
  button = mraa_gpio_init(62);

  int opt;
  static struct option long_options[] = {
  		{"period", required_argument, 0, 'p'},
  		{"scale", required_argument, 0, 's'},
  		{"log", required_argument, 0, 'l'},
  		// {"debug", no_argument, 0, 'd'},
  		{0, 0, 0, 0}
  };

  while( (opt = getopt_long(argc, argv, "", long_opts, NULL)) != -1){
		switch(opt){
			case 'p':
        break;
      case 'l':
        logFile = optarg;
				logging = 1;
        break;
      case 's':
        if (optarg[0] == 'C')
          scale = 'C';
				else if(optarg[0] == 'F')
          scale = 'F';
				else{
					fprintf(stderr, "Error: scale must be C or F \n");
					exit(1);
				}
        break;
      default:
        exit(1);

  if (logging) {
    logFile = fopen("lab4_2.log", "w");
  }


  pthread_t *threads = malloc(3 * sizeof(pthread_t));
  pthread_create(threads + 0, NULL, tempFunc, NULL);
  pthread_create(threads + 1, NULL, btnFunc, NULL);
  pthread_create(threads + 2, NULL, inputFunc, NULL);
  int i;
  for(i = 0 ; i < 3; i++){
    	pthread_join(threads[i], NULL);
  }

  if(logging){
    	int x=fclose(logFile);

  }

  free(threads);
  mraa_aio_close(tempSensor);
  mraa_aio_close(button);
}
